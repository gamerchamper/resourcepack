# Blossom Armor cross-edition test

This proof of concept contains a cute white/pink/gold armor set.

## Files

- `BlossomArmor-Java-26.2.zip`: unique item icons and worn armor assets for modern Java.
- `BlossomArmor-Java-1.8-Fallback.zip`: global diamond-armor replacement for 1.8 clients.
- `BlossomArmor-Bedrock.mcpack`: icons and armor textures for Geyser/Bedrock.
- `blossom-geyser-mappings.json`: Geyser v2 item mappings.
- `TEST-COMMANDS.txt`: commands for a direct 26.2 test.

## Important compatibility facts

ViaVersion and ViaBackwards do not backport resource-pack features. Java 1.8 has no CustomModelData or per-stack equipment assets. Its fallback therefore replaces every diamond armor texture. Modern Java can show a truly unique set when each item has both `item_model=blossom:...` and `equippable.asset_id=blossom:blossom`.

The 1.8 fallback and modern Java pack cannot be merged into one server-sent ZIP. Send the correct Java pack based on client protocol, or accept the global diamond fallback for old clients. Geyser receives the Bedrock pack separately.

## Install

1. Put the Bedrock `.mcpack`/ZIP in the Geyser Velocity `plugins/Geyser-Velocity/packs/` folder.
2. Put `blossom-geyser-mappings.json` in `plugins/Geyser-Velocity/custom_mappings/`.
3. Set `enable-custom-content: true` in Geyser and restart the proxy.
4. Host and send the Java 26.2 ZIP to modern Java clients. Use the fallback ZIP only for 1.8 testing.
5. Run the commands in `TEST-COMMANDS.txt` on Java 26.2.

## ItemEdit

ItemEdit 3.7.10 can store and distribute the finished ItemStacks, but the full modern test items need the `minecraft:item_model` and `minecraft:equippable` components. Create them once with the supplied commands, hold each item, then save it with ItemEdit/ServerItem. ItemEdit's numeric CustomModelData command by itself cannot change the worn armor texture on 1.8.
